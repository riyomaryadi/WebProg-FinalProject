

<link rel="stylesheet" href="/css/style_login.css">

<?php $__env->startSection('content'); ?>
        
            <div class="table table-bordered">
                <div class="">
                        <div class="table-header">
                            <div class="text">Login</div>
                        </div>
                </div>
                <div class="BodyTable_1">
                    <div>
                        <div>
                            <label for="" class="EmailnPass">E-Mail Address</label>
                            <input type="text" class="" id="">
                        </div>
                    </div>
                    <div>
                        <div>
                            <label for="">Password</label>
                            <input type="password" class="EmailnPass">
                        </div>
                    </div>
                </div>
                <div class="BodyTable_2">
                    <div>
                        <div class="">
                            <input class="" type="checkbox">
                            <label class="">Remember Me</label>
                        </div>
                    </div>
                    <div>
                        <button class="btn btn-primary" type="submit">Login</button>
                        <label for=""> <a href="#">Forgot Your Password?</a> </label>
                    </div>
                </div>
            </div>
        
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Tugas Kuliah\Semester 5\Web Programming[COMP6681001]\BI01\Project\project\resources\views/login.blade.php ENDPATH**/ ?>